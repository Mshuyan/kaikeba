package com.kkb.spring.factory;

import java.util.List;

/**
 * 可实现Bean的装配功能的的Bean工厂
 */
public interface AutowireCapableBeanFactory extends BeanFactory{

}
