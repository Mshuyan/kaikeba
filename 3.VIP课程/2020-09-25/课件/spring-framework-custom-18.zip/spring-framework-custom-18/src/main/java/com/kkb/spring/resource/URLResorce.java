package com.kkb.spring.resource;

import java.io.InputStream;

public class URLResorce implements Resource{
    @Override
    public InputStream getResource() {
        return null;
    }
}
